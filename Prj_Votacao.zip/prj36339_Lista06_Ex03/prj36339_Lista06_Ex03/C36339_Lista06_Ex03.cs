﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prj36339_Lista06_Ex03
{
    class C36339_Lista06_Ex03
    {
        static void Main(string[] args)
        {
            int c = 0;    //voto do candidato 1
            int d = 0;    //voto do candidato 2
            int t = 0;    //voto do candidato 3
            int Q = 0;    //Voto nulo
            int v = 0;    // voto
            int b = 0;    // numero de estudantes a votar
            int Vv = 0;   //numero de votos válidos
            double Pc = 0;   //porcentagem do candidato 1
            double Pd = 0;   // porcentagem do candidato 2
            double Pt = 0;   // porcentagem do candidato 3
            int z = 0;    //voto em branco

            Console.WriteLine("Votos: ");
            Console.WriteLine("Candidato 1 = 100 ");
            Console.WriteLine("Candidato 2 = 200 ");
            Console.WriteLine("Candidato 3 = 300 ");
            Console.WriteLine("Nulo = 400 ");
            Console.WriteLine("Em branco = 0 ");
            do
            {
                do
                {
                    Console.WriteLine("Digite o n° do seu voto: ");
                    v = int.Parse(Console.ReadLine());
                    if (v != 0 && v != 100 && v != 200 && v != 300 && v != 400)
                    {
                        Console.WriteLine("Digite um dos valores apresentados!");
                    }
                } while (v != 0 && v != 100 && v != 200 && v != 300 && v != 400);

                b = b + 1;
                if (v == 100 || v == 200 || v == 300)
                {
                    if (v == 100)
                    {
                        c = c + 1;
                    }
                    else
                    {
                        if (v == 200)
                        {
                            d = d + 1;
                        }
                        else
                        {
                            t = t + 1;
                        }
                    }
                }
                else
                {
                    if (v == 0)
                    {
                        z = z + 1;
                    }
                    else
                    {
                        Q = Q + 1;
                    }
                }

            } while (b < 10);

            Console.WriteLine("Quantidade de votos nulos: " + Q);

            Vv = c + d + t + z;
            Console.WriteLine("Quantidade de votos válidos: " + Vv);

            Pc = (c * 100) / Vv;
            Pd = (d * 100) / Vv;
            Pt = (t * 100) / Vv;

            Console.WriteLine("Candidato 1: " + c + " votos; " + Pc + "%");
            Console.WriteLine("Candidato 2: " + d + " votos; " + Pd + "%");
            Console.WriteLine("Candidato 3: " + t + " votos; " + Pt + "%");

            Console.ReadKey();
        }
    }
}
